let oddEven = document.getElementsByTagName("div");

for (let i = 0; i < oddEven.length; i++) {
  if (i % 2 == 0) {
    oddEven[i].style.backgroundColor = "orange";
  } else {
    oddEven[i].style.backgroundColor = "red";
  }
}
