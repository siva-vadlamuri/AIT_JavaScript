let borders = document.getElementsByTagName("div");
// console.log(borders.length);
for (let i = 0; i < borders.length; i++) {
  let border = borders[i].style;
  border.border = "2px solid red";
  border.padding = "10px";
  border.margin = "10px";
  border.borderRadius = "15px";
  border.textAlign = "center";
}
