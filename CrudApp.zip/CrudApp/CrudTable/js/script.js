let userData = {};
let selectedRow = null;
let readUserData = ()=>{
    userData["fullName"] = document.getElementById("fullName").value;
    userData["email"] = document.getElementById("email").value;
    userData["number"] = document.getElementById("number").value;
    return userData;
}
const insertUserData = (data) =>{
    let table = document.getElementById("userList").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);
    cell1 = newRow.insertCell(0);
    cell1.innerHTML = data.fullName;
    cell2 = newRow.insertCell(1);
    cell2.innerHTML = data.email;
    cell3 = newRow.insertCell(2);
    cell3.innerHTML = data.number;
    cell4 = newRow.insertCell(3);
   
    cell4.innerHTML = `<a onClick="onEdit(this)">Edit</a>
                       <a onClick="onDelete(this)">Delete</a>`;
}
function onEdit(td) {
    displayMe.style.display = 'flex';
    selectedRow = td.parentElement.parentElement;
    document.getElementById("fullName").value = selectedRow.cells[0].innerHTML;
    document.getElementById("email").value = selectedRow.cells[1].innerHTML;
    document.getElementById("number").value = selectedRow.cells[2].innerHTML;

}
const updateUserData=(formData) => {
    selectedRow.cells[0].innerHTML = formData.fullName;
    selectedRow.cells[1].innerHTML = formData.email;
    selectedRow.cells[2].innerHTML = formData.number;
}

const resetUserData = () =>{
    document.getElementById("fullName").value = "";
    document.getElementById("email").value = "";
    document.getElementById("number").value = "";
    selectedRow = null;
}
const onDelete =(td) => {
    if (confirm('Are you sure to delete this record ?')) {
        row = td.parentElement.parentElement;
        document.getElementById("userList").deleteRow(row.rowIndex);
        resetUserData();
    }
}
document.getElementById('submit').addEventListener('click', (event)=>{
    event.preventDefault();
    let data = readUserData(); 
    if(selectedRow==null){
        insertUserData(data);
        resetUserData();
        displayMe.style.display = 'none';
    }
    else{
        updateUserData(data);
    }
    

})

// document.getElementById('hideMe').addEventListener('click',()=>{
//     // alert('hi')
//     let displayMe = document.getElementById('hideMe');
//     displayMe.style.display = 'flex';
// })

// let addRowStyles = {
//     postion : 'relative',
//     left    : '300px',
// }

let displayMe = document.getElementById('hideMe');
document.getElementById('addData').addEventListener('click',()=>{
    let addDataButton = document.getElementById('addDataButton');
    
    displayMe.style.display = 'flex';
    addDataButton.setAttribute("style","position : relative; left : 534px");
})