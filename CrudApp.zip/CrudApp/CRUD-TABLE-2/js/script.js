/**
 * Modal Pop Up javaScript
 */
document.getElementById("button").addEventListener("click", function () {
  document.querySelector(".bg-modal").style.display = "flex";
});

document.querySelector(".close").addEventListener("click", function () {
  document.querySelector(".bg-modal").style.display = "none";
});

let selectedRow = null;

let UserData = [
  { name: "chaitanya", email: "chaitu@gmail.com", number: 9177190 },
  { name: "ganesh", email: "ganesh@gmail.com", number: 1245780 },
  { name: "ramesh", email: "ramesh@gmail.com", number: 9855474 },
  { name: "suresh", email: "suresh@gmail.com", number: 4587154 },
  { name: "harish", email: "harish@gmail.com", number: 9548722 },
];
let UserLoop = () => {
  //   console.log("two is called");
  var data = "";
  for (var i = 0; i < UserData.length; i++) {
    data = data + "<tr>";
    data = data + "<td>" + UserData[i].name + "</td>";
    data = data + "<td>" + UserData[i].email + "</td>";
    data = data + "<td>" + UserData[i].number + "</td>";

    data =
      data +
      `<td> <button type="button" class="btn btn-primary" onclick= onEdit(this)>edit</button> </td>`;

    data =
      data +
      `<td> <button  type="button" class="btn btn-danger" onclick= onDelete(${i})>Delete</button> </td>`;

    data = data + "</tr>";
  }

  document.getElementById("allitem").innerHTML = data;
};

window.addEventListener("load", UserLoop);

const updateUserData = (formData) => {
  selectedRow.cells[0].innerHTML = formData.name;
  selectedRow.cells[1].innerHTML = formData.email;
  selectedRow.cells[2].innerHTML = formData.number;
  document.querySelector(".bg-modal").style.display = "none";
};

let onEdit = (td) => {
  document.querySelector(".bg-modal").style.display = "flex";
  selectedRow = td.parentElement.parentElement;
  document.getElementById("name").value = selectedRow.cells[0].innerHTML;
  document.getElementById("email").value = selectedRow.cells[1].innerHTML;
  document.getElementById("phone").value = selectedRow.cells[2].innerHTML;
};
const onDelete = (index) => {
  if (confirm("Are you sure to delete this record ?")) {
    UserData.splice(index, 1);
    UserLoop();
  }
};
let saveMe = () => {
  let Newname = document.getElementById("name").value;
  let Newemail = document.getElementById("email").value;
  let Newnumber = document.getElementById("phone").value;
  console.log("I am in saveMe");
  if (Newname != "" && Newemail != "" && Newnumber != "") {
    let newData = {
      name: Newname,
      email: Newemail,
      number: Newnumber,
    };

    UserData.push(newData);
    document.querySelector(".bg-modal").style.display = "none";
    UserLoop();
  }
};
let readUserData = () => {
  UserData["name"] = document.getElementById("name").value;
  UserData["email"] = document.getElementById("email").value;
  UserData["number"] = document.getElementById("phone").value;
  return UserData;
};

document.getElementById("saveData").addEventListener("click", (event) => {
  event.preventDefault();

  if (selectedRow == null) {
    saveMe();
  } else {
    let data = readUserData();
    updateUserData(data);
  }
});
